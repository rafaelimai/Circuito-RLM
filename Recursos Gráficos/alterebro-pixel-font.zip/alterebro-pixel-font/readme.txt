﻿"Alterebro Pixel Font" is optimized for a font-size of 16 pixels
and multiples of 16 pixels.

---------------------------------------------------------------

LICENSE AND LEGAL NOTICE:

"Alterebro Pixel Font" by AlterEbro (Jorge Moreno aka Moro)
is licensed under a Creative Commons Attribution Non-commercial license
(http://creativecommons.org/licenses/by-nc/3.0/).

By using this font you must comply with the licensing terms described in the link above.
If you redistribute the font file in this archive, it must be accompanied by all the other
files from this archive, including this one.

---------------------------------------------------------------

www.alterebro.com (Jorge Moreno)
http://www.alterebro.com/works/design/alterebro-pixel-font.ae